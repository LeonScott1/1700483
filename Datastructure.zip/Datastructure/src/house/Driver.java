package house;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.Scanner;

public class Driver {
	public static void main(String args[] )
	{
	House house;
	Photo image;
	
	int identification;
	float price;
	String location;
	String advertiser;
	int length;
	int width;
	int count=0;
	
	Scanner scanner=new Scanner(System.in);
	while(count<3)
	{
	System.out.println("Please enter Id Number");
	identification= scanner.nextInt();
	System.out.println("Please enter price of house");
	price=scanner.nextFloat();
	System.out.println("Please enter location of house");
	location=scanner.next();
	System.out.println("Please enter advertister of house");
	advertiser=scanner.next();
	System.out.println("Please enter lenght of the photo");
	length=scanner.nextInt();
	System.out.println("Please enter width of the photo");
	width=scanner.nextInt();
	count++;
	image=new Photo (length, width);
	house = new House(identification, price, location, advertiser, image );

	house.store(house);
	
	}
	scanner.close();
	
	try {
		view();
	} catch (ClassNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}

}
	
	public static void view() throws ClassNotFoundException
	{
		System.out.println("printing from the file");
		FileInputStream fis;
		ObjectInputStream ois;
		try {
			fis=new FileInputStream(new File("house.txt"));
			ois=new ObjectInputStream(fis);
			
			//read obj
			House h1=(House)ois.readObject();
			House h2=(House)ois.readObject();
			House h3=(House)ois.readObject();
			
			
			System.out.println(h1.toString());
			System.out.println(h2.toString());
			System.out.println(h3.toString());
			ois.close();
			fis.close();
		
		}catch(IOException p)
		{
			
		}
	}
	 
	

}
